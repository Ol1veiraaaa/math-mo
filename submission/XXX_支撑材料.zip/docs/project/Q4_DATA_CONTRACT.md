# Q4 Actual-Schedule Data Contract

The comparison uses the completed 2022 FIFA World Cup group stage. The raw
OpenFootball schedule and stadium snapshot are retained under `research/q4/`,
with provenance recorded in `research/q4/SOURCE.md` and cryptographic hashes in
`outputs/q4/source_hashes.json`.

`scripts/collect_q4_openfootball.py` parses the source into
`outputs/q4/actual_schedule.csv` without hand-entering match rows. The output
follows the organizer's `actual_schedule_template.csv` column order and keeps a
source URL and retrieval date on every row. The parser/validator confirms:

- 48 group matches, 8 groups and 32 teams;
- 6 matches per group and 3 matches per team;
- 8 named venues;
- local Qatar time converted to UTC+00:00;
- unique match identifiers and finite score fields.

`scripts/run_q4_comparison.py` compares the actual tournament with the
72-match, 48-team Q2 COPT schedule. Because scale and geography differ, it uses
per-team travel, per-transition travel, rest distributions, timezone crossings,
venue-load CV/HHI and mean capacity. Travel measures venue-to-venue transitions
only; it excludes team origin to first venue because the public schedule does
not provide an equivalent origin mapping.

The comparison is deliberately nonuniform: Qatar 2022 has far lower travel and
no timezone crossings, while the simulated optimized plan has longer rest,
higher mean capacity and lower venue-share HHI. In the current run these are
4,257.17 versus 37.93 travel km per team, 167.81 versus 97.81 mean rest hours,
71,353 versus 54,202 mean capacity, and 0.0702 versus 0.1259 venue HHI. No historical ticket,
broadcast, attendance, golden-slot, fairness or risk value is invented. Those
dimensions are discussed as unavailable rather than silently scored.
