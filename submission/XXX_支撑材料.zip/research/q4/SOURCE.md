# Q4 Source Snapshot

The 2022 FIFA World Cup group-stage schedule and stadium data were retrieved on
2026-08-14 from the public OpenFootball World Cup repository:

- schedule: https://github.com/openfootball/worldcup/blob/master/2022--qatar/cup.txt
- stadiums: https://github.com/openfootball/worldcup/blob/master/2022--qatar/stadiums.csv

The schedule raw file was downloaded from GitHub after its visible file page
was verified in the in-app browser. The stadium raw endpoint repeatedly reset,
so `openfootball_2022_stadiums.csv` is a verbatim local snapshot of the complete
928-character file content exposed by the same visible GitHub file page.

The parser retains the row-level schedule page URL in `source_url` and the
retrieval date in every generated actual-schedule record. It does not use goal
scorer annotations in the comparison model.
