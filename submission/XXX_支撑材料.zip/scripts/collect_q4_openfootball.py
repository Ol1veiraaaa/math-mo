from __future__ import annotations

import hashlib
import json
import re
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from c_contest_q1.q4_demo import ACTUAL_REQUIRED, validate_actual_schedule


SOURCE_URL = "https://github.com/openfootball/worldcup/blob/master/2022--qatar/cup.txt"
RETRIEVAL_DATE = "2026-08-14"
GROUPS = {
    "A": ["Qatar", "Ecuador", "Senegal", "Netherlands"],
    "B": ["England", "Iran", "USA", "Wales"],
    "C": ["Argentina", "Saudi Arabia", "Mexico", "Poland"],
    "D": ["France", "Australia", "Denmark", "Tunisia"],
    "E": ["Spain", "Costa Rica", "Germany", "Japan"],
    "F": ["Belgium", "Canada", "Morocco", "Croatia"],
    "G": ["Brazil", "Serbia", "Switzerland", "Cameroon"],
    "H": ["Portugal", "Ghana", "Uruguay", "South Korea"],
}
DATE_PATTERN = re.compile(r"^(?:Sun|Mon|Tue|Wed|Thu|Fri|Sat)\s+(Nov|Dec)\s+(\d{1,2})\s*$")
MATCH_PATTERN = re.compile(
    r"^\s*(?:(\d{1,2}:\d{2})\s+)?(.+?)\s+(\d+)-(\d+)"
    r"(?:\s+\(\d+-\d+\))?\s+(.+?)\s+@\s+(.+?),\s+(.+?)\s*$"
)


def parse_schedule(path: Path) -> pd.DataFrame:
    text = path.read_text(encoding="utf-8-sig")
    group: str | None = None
    current_date: datetime | None = None
    current_time: str | None = None
    group_match_count = {key: 0 for key in GROUPS}
    rows: list[dict[str, object]] = []
    for raw_line in text.splitlines():
        line = raw_line.strip()
        group_match = re.fullmatch(r"\u25aa\s*Group\s+([A-H])", line)
        if group_match:
            group = group_match.group(1)
            current_time = None
            continue
        date_match = DATE_PATTERN.fullmatch(line)
        if date_match and group:
            month = 11 if date_match.group(1) == "Nov" else 12
            current_date = datetime(2022, month, int(date_match.group(2)))
            current_time = None
            continue
        if not group or current_date is None or "@" not in line:
            continue
        match = MATCH_PATTERN.match(raw_line)
        if not match:
            raise ValueError(f"unparsed match line: {raw_line!r}")
        explicit_time, team_a, goals_a, goals_b, team_b, venue, city = match.groups()
        current_time = explicit_time or current_time
        if current_time is None:
            raise ValueError(f"match without explicit or inherited time: {raw_line!r}")
        team_a, team_b = team_a.strip(), team_b.strip()
        if team_a not in GROUPS[group] or team_b not in GROUPS[group]:
            raise ValueError(f"unexpected teams in group {group}: {team_a}, {team_b}")
        group_match_count[group] += 1
        round_number = (group_match_count[group] - 1) // 2 + 1
        hour, minute = map(int, current_time.split(":"))
        local = current_date.replace(hour=hour, minute=minute, tzinfo=timezone(timedelta(hours=3)))
        rows.append({
            "match_id": f"WC22-{group}{group_match_count[group]:02d}",
            "competition": "2022 FIFA World Cup Qatar",
            "stage": "Group Stage",
            "group_id": group,
            "round_in_group": round_number,
            "team_a": team_a,
            "team_b": team_b,
            "venue": venue.strip(),
            "city": city.strip(),
            "country": "Qatar",
            "date": local.date().isoformat(),
            "local_kickoff_time": current_time,
            "utc_datetime": local.astimezone(timezone.utc).isoformat(),
            "goals_a": int(goals_a),
            "goals_b": int(goals_b),
            "source_url": SOURCE_URL,
            "retrieval_date": RETRIEVAL_DATE,
        })
    result = pd.DataFrame(rows, columns=ACTUAL_REQUIRED)
    if len(result) != 48 or group_match_count != {key: 6 for key in GROUPS}:
        raise ValueError(f"expected 48 matches and six per group, got {len(result)} / {group_match_count}")
    appearances = pd.concat([result.team_a, result.team_b]).value_counts()
    if len(appearances) != 32 or not appearances.eq(3).all():
        raise ValueError("each of the 32 actual teams must appear exactly three times")
    errors = validate_actual_schedule(result)
    if errors:
        raise ValueError("; ".join(errors))
    return result


def main() -> None:
    source = ROOT / "research" / "q4" / "openfootball_2022_cup.txt"
    stadiums = ROOT / "research" / "q4" / "openfootball_2022_stadiums.csv"
    out = ROOT / "outputs" / "q4"
    out.mkdir(parents=True, exist_ok=True)
    schedule = parse_schedule(source)
    schedule.to_csv(out / "actual_schedule.csv", index=False)
    hashes = {
        path.name: hashlib.sha256(path.read_bytes()).hexdigest()
        for path in (source, stadiums)
    }
    (out / "source_hashes.json").write_text(json.dumps(hashes, indent=2), encoding="utf-8")
    print(schedule.head().to_string(index=False))
    print({"rows": len(schedule), "groups": schedule.group_id.nunique(), "teams": pd.concat([schedule.team_a, schedule.team_b]).nunique(), "venues": schedule.venue.nunique()})


if __name__ == "__main__":
    main()
